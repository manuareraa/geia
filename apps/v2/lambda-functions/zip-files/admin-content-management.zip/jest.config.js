export default {
    "moduleFileExtensions": ["js", "json"],
    "transform": {},
    "moduleNameMapper": {
      "^@/(.*)$": "<rootDir>/$1"
    },
    "testMatch": ["<rootDir>/test.js"]
  }
  